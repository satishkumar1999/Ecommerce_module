<?php
include 'db.php';

// API Request Handle करना
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $user_id = $_POST['user_id'];

    if ($action == "get_balance") {
        $query = "SELECT balance FROM users WHERE id = $user_id";
        $result = $conn->query($query);
        $data = $result->fetch_assoc();
        echo json_encode(["balance" => $data['balance']]);

    } elseif ($action == "add_cashback") {
        $purchase_amount = $_POST['purchase_amount'];
        $category_percentage = $_POST['category_percentage'];
        $cashback_amount = ($purchase_amount * $category_percentage) / 100;

        $query = "UPDATE users SET balance = balance + $cashback_amount WHERE id = $user_id";
        $conn->query($query);

        echo json_encode(["message" => "Cashback Added: ₹" . $cashback_amount]);

    } elseif ($action == "use_cashback") {
        $use_amount = $_POST['use_amount'];

        $query = "SELECT balance FROM users WHERE id = $user_id";
        $result = $conn->query($query);
        $data = $result->fetch_assoc();

        if ($data['balance'] >= $use_amount) {
            $query = "UPDATE users SET balance = balance - $use_amount WHERE id = $user_id";
            $conn->query($query);
            echo json_encode(["message" => "Cashback Used: ₹" . $use_amount]);
        } else {
            echo json_encode(["error" => "Insufficient Balance"]);
        }
    }
}
?>
