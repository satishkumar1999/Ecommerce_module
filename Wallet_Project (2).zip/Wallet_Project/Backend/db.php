<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "wallet_db";

// MySQL कनेक्शन
$conn = new mysqli($host, $username, $password, $database);

// कनेक्शन चेक करें
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
