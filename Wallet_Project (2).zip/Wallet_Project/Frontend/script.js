
const API_URL = "https://walletproject.great-site.net/wallet.php";




function getBalance() {
    let user_id = document.getElementById("user_id").value;
    fetch(API_URL, {
        method: "POST",
        body: new URLSearchParams({ action: "get_balance", user_id })
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById("wallet_balance").innerText = data.balance;
    });
}

function addCashback() {
    let user_id = document.getElementById("user_id").value;
    let purchase_amount = document.getElementById("purchase_amount").value;
    let category_percentage = document.getElementById("category").value;

    fetch(API_URL, {
        method: "POST",
        body: new URLSearchParams({ action: "add_cashback", user_id, purchase_amount, category_percentage })
    })
    .then(res => res.json())
    .then(data => alert(data.message));
}

function useCashback() {
    let user_id = document.getElementById("user_id").value;
    let use_amount = document.getElementById("use_amount").value;

    fetch(API_URL, {
        method: "POST",
        body: new URLSearchParams({ action: "use_cashback", user_id, use_amount })
    })
    .then(res => res.json())
    .then(data => alert(data.message));
}
